document.getElementById("searchid").addEventListener("keyup", function() {
    let food = this.value.toLowerCase();
    let items = document.querySelectorAll(".food-item");

    items.forEach(item => {
        let name = item.getAttribute("data-name").toLowerCase();
        if (name.includes(food)) {
            item.style.display = "block";
        } else {
            item.style.display = "none";
        }
    });
});