let cart = [];

function addToCart(name, price) {
  const existing = cart.find(item => item.name === name);
  if (existing) {
    existing.quantity += 1;
  } else {
    cart.push({ name, price, quantity: 1 });
  }
  updateCartDisplay();
  updateCartCount();
}

function updateCartCount() {
  const count = cart.reduce((sum, item) => sum + item.quantity, 0);
  document.getElementById('cart-count').textContent = count;
}


function updateCartDisplay() {
  const cartItemsContainer = document.getElementById('cart-items');
  const totalAmountElem = document.getElementById('cart--total');

  cartItemsContainer.innerHTML = '';
  let total = 0;

  cart.forEach(item => {
    const cartRow = document.createElement('div');
    cartRow.className = 'flex justify-between py-1 px-2 bg-gray-100 rounded mb-1';
    cartRow.innerHTML = `
    <button class="delete-item text-red-500 hover:text-red-700 font-bold" data-name="${item.name}">X</button>
      <span>${item.name} x ${item.quantity} = </span>
      <div class="flex items-center gap-2">
      

      <span>${item.price * item.quantity}</span>
      
      </div>


    `;
    cartItemsContainer.appendChild(cartRow);
    total += item.price * item.quantity;
  });

  totalAmountElem.textContent = `${total}`;

  document.querySelectorAll('.delete-item').forEach(button => {
    button.addEventListener('click', function () {
      const name = this.getAttribute('data-name');
      deleteFromCart(name);
    });
  });



}
function deleteFromCart(name) {
  cart = cart.filter(item => item.name !== name);
  updateCartDisplay();
  updateCartCount();
}



document.querySelectorAll('.add-to-cart').forEach(img => {
  img.addEventListener('click', function () {
    const name = img.getAttribute('data-name');
    const price = parseFloat(img.getAttribute('data-price'));
    addToCart(name, price);
  });
});

document.getElementById('Order-now').addEventListener('click', function() {
  document.querySelector('.order').classList.remove('hidden');


});

document.querySelector('.checkout-btn').addEventListener('click', function () {
  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  localStorage.setItem('cartTotal', total);
 window.location.href = "checkout.html";
});

document.addEventListener('DOMContentLoaded', () => {
  const total = localStorage.getItem('cartTotal');
  document.getElementById('final-total').textContent = `${total}`;
});


