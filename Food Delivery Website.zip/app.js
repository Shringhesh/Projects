


















import './new.css';
function App() {
    return (
        <p className='text-center text-green-500 font-bold'>
        Hi Mom!

        </p>
    );
}
export default App;