document.getElementById("signInForm").addEventListener("submit", function (event) {
  event.preventDefault();

  const email = document.getElementById("signInEmail").value;
  const password = document.getElementById("signInPassword").value;

  const storedUser = localStorage.getItem(email);

  if (storedUser) {
    const userObj = JSON.parse(storedUser);

    if (userObj.password === password) {
      alert("Login successful!");

      // Store currently logged-in user
      localStorage.setItem("currentUser", storedUser);

      // Redirect to profile page
      window.location.href = "swiggy.html";
    } else {
      alert("Incorrect password");
    }
  } else {
    alert("User not found");
  }
});


