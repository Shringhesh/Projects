document.getElementById('sidebar-close').addEventListener('click', function ()  {
  document.querySelector('.sidebar').classList.add('hidden');

});
const shoppingCart = document.querySelector('.image').addEventListener('click', function() {
  document.querySelector('.sidebar').classList.remove('hidden');
});








const togglebtn = document.querySelectorAll(".toggle-button");
const dropdown = document.querySelectorAll(".dropdown-menu");

togglebtn.forEach(btn => {
  btn.addEventListener("click", () => {
    dropdown.forEach(menu => {
      menu.classList.toggle("top-[10px]");
    });
  });
});

 





document.getElementById("searchid").addEventListener("keyup", function() {
    let food = this.value.toLowerCase();
    let items = document.querySelectorAll(".food-item");

    items.forEach(item => {
        let name = item.getAttribute("data-name").toLowerCase();
        if (name.includes(food)) {
            item.style.display = "block";
        } else {
            item.style.display = "none";
        }
    });
});













