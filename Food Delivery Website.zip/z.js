document.getElementById("signUpForm").addEventListener("submit", function (event) {
    event.preventDefault(); // Prevent form from refreshing

    // Get user input values
    const username = document.getElementById("signUpUsername").value;
    const email = document.getElementById("signUpEmail").value;
    const password = document.getElementById("signUpPassword").value;

    var user = {
        username: username,
        email: email,
        password: password
    }

    var json = JSON.stringify(user);
    localStorage.setItem(email,json);
    console.log("user added");
    alert("Sign Up Successfull");
    window.location.href = "swiggy.html";

});





document.addEventListener("DOMContentLoaded", () => {
  const user = JSON.parse(localStorage.getItem("user"));

  if (user) {
    document.getElementById("displayUsername").textContent = user.username;
    document.getElementById("displayEmail").textContent = user.email;
  }

  const profileBtn = document.getElementById("profileBtn");
  const profileMenu = document.getElementById("profileMenu");

  profileBtn.addEventListener("click", () => {
    profileMenu.classList.toggle("hidden");
  });

  document.addEventListener("click", (e) => {
    if (!profileBtn.contains(e.target) && !profileMenu.contains(e.target)) {
      profileMenu.classList.add("hidden");
    }
  });
});


















const myButton= document.getElementById("mybutton");
myButton.classList.add("enabled");
myButton.classList.remove("enabled");
const Button2=document.getElementById("button2");
Button2.addEventListener("mouseover",event =>{
    event.target.classList.add("enabled");
})
    Button2.addEventListener("mouseout",event =>{
    event.target.classList.remove("enabled");

})
const Button3= document.getElementById("button3");
Button3.classList.add("enabled");
Button3.addEventListener("click", event =>{


    if(event.target.classList.contains("disabled")){
        event.target.textContent += "🤑";
    }
    else {
        event.target.classList.replace("enabled","disabled")

    }

})

let Buttons= document.querySelectorAll(".mybuttons");
Buttons.forEach(button =>{
    button.classList.add("enabled");
     
})
Buttons.forEach(button =>{
    button.addEventListener("mouseover",event =>{
        event.target.classList.toggle("disabled");
    })
})
Buttons.forEach(button =>{
    button.addEventListener("mouseout",event =>{
        event.target.classList.toggle("disabled");
    })
})